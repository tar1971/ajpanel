#!/bin/bash
######################################################################################
## Command=wget https://raw.githubusercontent.com/tarekzoka/EPG/main/EPGDAT.sh -O - | /bin/sh
##
echo
wget -O /etc/enigma2/epg.dat https://github.com/tarekzoka/EPG/raw/main/epg.dat
wait
wget -O /media/hdd/epg.dat https://github.com/tarekzoka/EPG/raw/main/epg.dat
sleep 2;
exit 0  
qq
