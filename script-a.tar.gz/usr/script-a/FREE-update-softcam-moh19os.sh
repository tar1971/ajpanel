wget -O /etc/tuxbox/config/SoftCam.Key https://raw.githubusercontent.com/MOHAMED19OS/SoftCam_Emu/main/Enigma2/SoftCam.Key

