
#!/bin/sh
#

wget -O /tmp/enigma2-plugin-extensions-ajpanel_v8.8.5.tar.xz "https://raw.githubusercontent.com/tarekzoka/ajpanel/main/enigma2-plugin-extensions-ajpanel_v8.8.5.tar.xz"

tar -xzf /tmp/*.tar.xz -C /

rm -r /tmp/enigma2-cinogri-pli-fhd-novaler-skin_1.4b.tar.gz

killall -9 enigma2

sleep 2;
