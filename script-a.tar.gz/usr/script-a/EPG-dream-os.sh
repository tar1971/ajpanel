ee
rm -rf /etc/enigma2/epg.db
wait
rm -rf /etc/hdd/epg.db
wait
wget -O /etc/enigma2/epg.db "https://drive.google.com/uc?id=14bhJSw6Xf9ywVuPhjyT4CoSmzjM8BA1a&export=download"
wait
wget -O /media/hdd/epg.db "https://drive.google.com/uc?id=14bhJSw6Xf9ywVuPhjyT4CoSmzjM8BA1a&export=download"

killall -9 enigma2

sleep 2;

exit 0
ee
