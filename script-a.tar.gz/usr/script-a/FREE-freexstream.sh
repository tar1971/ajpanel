#!/bin/sh
#

wget -O /etc/enigma2/xstreamity/playlists.txt "https://drive.google.com/uc?id=1dqK_37TIWTTA2W5NZF-_r5KDeVJfp8hX&export=download"

exit 0



