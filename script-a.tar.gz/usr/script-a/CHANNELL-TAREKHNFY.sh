echo

rm -f /etc/defaultsat.tar.gz && rm -f /etc/enigma2/lamedb && rm -f /etc/enigma2/*.tv && rm -f /etc/enigma2/*.radio && rm -f /etc/enigma2/*.del && rm -f /etc/enigma2/*.sh && wait

wget "https://raw.githubusercontent.com/tarekzoka/CHANNELL/main/CHANNELL-TAREK-HNFY.tar.gz"


tar -xzf CHANNELL-TAREK-HNFY.tar.gz  -C /

wait
rm -f /tmp/CHANNELL-TAREK-HNFY.tar.gz
echo "   UPLOADED BY  >>>>   TAREK_TT "   
sleep 4;                                                                                                                  
echo ". >>>>         RESTARING     <<<<"
echo "**********************************************************************************"
wait
killall -9 enigma2
exit 0
