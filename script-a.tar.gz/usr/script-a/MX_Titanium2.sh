echo
#!/bin/sh
#

wget -O /tmp/Skin-MX-Titanium-By-Matrix10-MoD.tar.gz "https://raw.githubusercontent.com/tarekzoka/SKINS/main/Skin-MX-Titanium-By-Matrix10-MoD.tar.gz"

tar -xzf /tmp/*.tar.gz -C /

rm -r /tmp/Skin-MX-Titanium-By-Matrix10-MoD.tar.gz

killall -9 enigma2

sleep 2;
