echo
opkg update
wait
sleep 2;
exit 0
