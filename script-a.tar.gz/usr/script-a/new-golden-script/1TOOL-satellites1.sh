wget -O /etc/tuxbox/satellites.xml https://raw.githubusercontent.com/oe-alliance/oe-alliance-tuxbox-common/master/src/satellites.xml
wait
sleep 3;
exit











