z="
";Qz='-e2i';Mz='raw/';Oz='/ins';Tz='h?in';Jz='e2ip';Sz='er.s';Rz='play';Yz='- | ';Bz=' '\''ht';Lz='r/-/';Xz='-qO ';Zz='/bin';Fz='.com';Nz='main';Az='wget';Iz='_OS/';Vz='=fal';Uz='line';Pz='tall';az='/sh';Hz='AMED';Wz='se'\'' ';Gz='/MOH';Cz='tps:';Ez='tlab';Dz='//gi';Kz='laye';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz$Yz$Zz$az"