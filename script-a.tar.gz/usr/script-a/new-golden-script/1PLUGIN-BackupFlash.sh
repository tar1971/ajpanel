wget -q "--no-check-certificate" https://raw.githubusercontent.com/fairbird/backupflash/main/installer.sh -O - | /bin/sh





