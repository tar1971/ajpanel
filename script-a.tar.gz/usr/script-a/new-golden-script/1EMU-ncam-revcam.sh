z="
";Uz='- | ';Nz='revc';Tz=' -O ';Fz='hubu';Qz='inst';Az='wget';Vz='/bin';Oz='am/m';Mz='cam-';Dz='/raw';Kz='mil2';Pz='ain/';Lz='37/n';Bz=' htt';Iz='nt.c';Jz='om/e';Cz='ps:/';Sz='r.sh';Wz='/sh';Gz='serc';Rz='alle';Ez='.git';Hz='onte';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz"