z="
";Sz='nsta';Bz=' htt';Ez='.git';Wz='- | ';Oz='mil-';Jz='om/e';Rz='in/i';Nz='el-e';Uz='.sh ';Cz='ps:/';Yz='/sh';Xz='/bin';Tz='ller';Kz='mil2';Iz='nt.c';Mz='hann';Fz='hubu';Lz='37/c';Dz='/raw';Gz='serc';Pz='nabi';Hz='onte';Az='wget';Vz='-qO ';Qz='l/ma';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz$Yz"