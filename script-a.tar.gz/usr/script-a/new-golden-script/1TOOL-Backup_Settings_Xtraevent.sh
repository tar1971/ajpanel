#!/bin/sh
echo "Backup Settings Xtraevent"
sleep 1
WORD='xtraEvent'; BACKUP='/tmp/settings_backup_xtraEvent'; grep $WORD '/etc/enigma2/settings' > $BACKUP

exit



