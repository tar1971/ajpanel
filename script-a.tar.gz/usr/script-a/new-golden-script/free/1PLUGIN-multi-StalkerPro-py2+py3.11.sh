wget https://raw.githubusercontent.com/emilnabil/MultiStalkerPro/main/installer.sh -qO - | /bin/sh

