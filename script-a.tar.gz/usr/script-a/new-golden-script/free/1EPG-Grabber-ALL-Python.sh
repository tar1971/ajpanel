wget -q "--no-check-certificate" https://raw.githubusercontent.com/zKhadiri/Epg-plugin/master/Download/installer.sh -O - | /bin/sh






