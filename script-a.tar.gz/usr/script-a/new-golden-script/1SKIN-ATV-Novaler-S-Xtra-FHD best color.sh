z="
";Gz='serc';Sz='inst';Iz='nt.c';Rz='ain/';Dz='/raw';Vz=' -qO';Oz='vale';Xz=' /bi';Yz='n/sh';Jz='om/e';Qz='ra/m';Ez='.git';Bz=' htt';Tz='alle';Kz='miln';Pz='r-xt';Wz=' - |';Nz='n-no';Mz='/ski';Cz='ps:/';Lz='abil';Az='wget';Fz='hubu';Hz='onte';Uz='r.sh';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz$Yz"

