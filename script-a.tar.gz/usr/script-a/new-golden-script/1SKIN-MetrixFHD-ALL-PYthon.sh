wget -q "--no-check-certificate" https://raw.githubusercontent.com/emil237/Skin-Metrix-FHD/main/MetrixFHD.sh -O - | /bin/sh


