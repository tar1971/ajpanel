z="
";Xz='in/s';Oz='ra19';Qz='main';Wz='| /b';Rz='/ins';Vz='O - ';Dz='/raw';Ez='.git';Iz='nt.c';Uz='h -q';Az='wget';Kz='mil2';Fz='hubu';Nz='-ast';Cz='ps:/';Gz='serc';Yz='h';Pz='.2e/';Jz='om/e';Bz=' htt';Lz='37/p';Hz='onte';Tz='er.s';Sz='tall';Mz='icon';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz$Yz"