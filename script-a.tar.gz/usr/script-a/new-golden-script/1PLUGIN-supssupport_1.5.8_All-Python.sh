z="
";Hz='onte';Rz='alle';Fz='hubu';Iz='nt.c';Nz='uppo';Tz=' -O ';Lz='37/S';Oz='rt/m';Mz='ubsS';Ez='.git';Wz='/sh';Dz='/raw';Bz=' htt';Sz='r.sh';Jz='om/e';Vz='/bin';Az='wget';Qz='inst';Gz='serc';Pz='ain/';Uz='- | ';Kz='mil2';Cz='ps:/';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz"