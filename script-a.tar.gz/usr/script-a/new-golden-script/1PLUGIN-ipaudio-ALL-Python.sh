z="
";Sz='37/i';Ez='eck-';Rz='mil2';Kz='/raw';Vz='ain/';Iz=' htt';Oz='onte';Mz='hubu';bz='/bin';Gz='ific';Qz='om/e';Yz='r.sh';Xz='alle';Cz='"--n';az='- | ';Jz='ps:/';Hz='ate"';Pz='nt.c';Lz='.git';Az='wget';Dz='o-ch';Fz='cert';Zz=' -O ';Wz='inst';Tz='paud';Uz='io/m';Bz=' -q ';cz='/sh';Nz='serc';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz$Yz$Zz$az$bz$cz"