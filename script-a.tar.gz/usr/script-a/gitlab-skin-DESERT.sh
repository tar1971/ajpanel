echo
#!/bin/sh
#

wget -O /tmp/DesertFHD.tar.gz "https://gitlab.com/hanfy1971/skins/-/raw/main/DesertFHD.tar.gz"

tar -xzf /tmp/*.tar.gz -C /

wait

rm -f /tmp/DesertFHD.tar.gz
echo "   UPLOADED BY  >>>>   TAREK_TT "   
sleep 4;                                                                                                                  
echo ". >>>>         RESTARING     <<<<"
echo BY-TAREK-HANFY   "**********************************************************************************"
wait
killall -9 enigma2
exit 0
qq
