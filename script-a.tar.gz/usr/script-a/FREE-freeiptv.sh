#!/bin/sh
#

wget -O /etc/tsiplayer_xtream.conf "https://drive.google.com/uc?id=1LzI4w3QykN0xodJWT_FeFqJsrXHXOdnz&export=download"

exit 0



