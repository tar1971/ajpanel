wget -O /etc/enigma2/iptv.sh "http://20062016.com:80/get.php?username=mohammed5555&password=mohammed5555&type=enigma22_script&output=ts" && chmod 777 /etc/enigma2/iptv.sh && /etc/enigma2/iptv.sh
