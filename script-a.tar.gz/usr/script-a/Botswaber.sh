echo

rm -rf /usr/lib/enigma2/python/Plugins/Extensions/BootLogoSwapper

wait


#!/bin/sh
#

wget -O /tmp/TARKBootLogoSwapperPicture.tar.gz "https://raw.githubusercontent.com/tarekzoka/bootlogo/main/TARKBootLogoSwapperPicture.tar.gz"

tar -xzf /tmp/*.tar.gz -C /

rm -r /tmp/TARKBootLogoSwapperPicture.tar.gz

echo "         UPLOADED BY TARK_HANFY    "


killall -9 enigma2

sleep 2;

wwww
