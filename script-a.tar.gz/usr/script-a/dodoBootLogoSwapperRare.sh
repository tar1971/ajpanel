echo
#!/bin/sh
#

wget -O /tmp/dodoBootLogoSwapperRarePicture.tar.gz "https://raw.githubusercontent.com/tarekzoka/bootlogo/main/dodoBootLogoSwapperRarePicture.tar.gz"

tar -xzf /tmp/*.tar.gz -C /

rm -r /tmp/dodoBootLogoSwapperRarePicture.tar.gz

echo "         UPLOADED BY TARK_HANFY    "


killall -9 enigma2

sleep 2;
