echo
wget https://raw.githubusercontent.com/tarekzoka/ipaudio/main/installerf.sh -O - | /bin/sh
