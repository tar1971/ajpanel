echo

rm -rf /usr/lib/enigma2/python/Plugins/Extensions/EPGGrabber/api/epg_status.json
wait
sleep 2;
exit



