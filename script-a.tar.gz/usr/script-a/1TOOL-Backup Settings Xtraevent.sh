echo
#!/bin/sh
echo "Backup Settings Xtraevent"
sleep 1
WORD='xtraEvent'; BACKUP='/tmp/settings_backup_xtraEvent'; grep $WORD '/etc/enigma2/settings' > $BACKUP
wait
WORD='xtraEvent'; BACKUP='/usr/script/settings_backup_xtraEvent'; grep $WORD '/etc/enigma2/settings' > $BACKUP
wait
WORD='xtraEvent'; BACKUP='/media/hdd/settings_backup_xtraEvent'; grep $WORD '/etc/enigma2/settings' > $BACKUP
exit
qq
