echo
rm -rf /etc/enigma2/jediplaylists/playlists.txt
wait
rm -rf /etc/tuxbox/config/CCcam.cfg
wait
rm -rf /etc/tuxbox/config/ncam.server
wait
rm -rf /etc/tuxbox/config/oscam.server
wait
rm -rf /etc/enigma2/xstreamity/playlists.txt
wait
rm -rf /etc/enigma2/xstreamity/x-playlists.txt
wait
rm -rf /etc/enigma2/iptosat.conf
wait
rm -rf /etc/enigma2/ipaudio.json
echo
rm -rf /etc/enigma2/iptosat.json
wait
rm -rf /etc/enigma2/xstreamity/playlists.txt
wait
rm -f /etc/enigma2/playlists.txt
wait
rm -f /etc/enigma2/playlist.e2pls
wait
rm -f /etc/enigma2/dreamxtream.json
wait
rm -f /etc/tsiplayer_xtream.conf
wait
#!/bin/sh
#
rm -r /usr/script-a
sleep 2;
exit
echo




