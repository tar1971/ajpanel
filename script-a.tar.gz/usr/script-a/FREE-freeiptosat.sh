#!/bin/sh
#

wget -O /etc/enigma2/iptosat.json "https://drive.google.com/uc?id=1gY_rvfqMaOTkSb-fPKY5HACpvC8jJRqT&export=dwnload"

exit 0



