wait

#!/bin/sh
#

wget -O /etc/epgimport/ziko_epg/jawwyen.xml "https://github.com/MOHAMED19OS/XMLTV/raw/main/jawwyen.xml"

wait

wget -O /etc/epgimport/ziko_epg/jawwytv.xml "https://github.com/MOHAMED19OS/XMLTV/raw/main/jawwytv.xml"

wait
wget -O /etc/epgimport/ziko_epg/osn.xml "https://github.com/MOHAMED19OS/XMLTV/raw/main/osn.xml"

exit 0

