echo
#!/bin/sh
#
rm -r /hdd/epg.dat

wget -O /tmp/epg.tar.gz "https://drive.google.com/uc?id=1CbgD8tEIARplJtFrL0CN8LGrPSMq1JYx&export=download"

tar -xzf /tmp/*.tar.gz -C /

rm -r /tmp/epg.tar.gz

killall -9 enigma2

sleep 2;

exit 0
























